<?php defined( '_VALID_MOS' ) or die( include("../../content/news/404.php") );

    //ini_set('display_errors', 1);
    // ini_set('display_startup_errors', 1);
    // error_reporting(E_ALL);
    
    include 'interface.skin.view.admin.process.php';
    $proc = new PageData(true);   
    
    // Xử lý
    ?>
<style>
    .imgPreview {
        display: block;
        max-width: 450px;
        margin: 0 auto;
    }

    .control-group {
        border-bottom: 1px solid #ededed;
        /*padding: 10px 0;*/
        margin: 5px 0;
    }

    .control-group label {
        font-size: 0.9rem;
        font-weight: bold;
    }

    .accordion-inner .control-group:last-child {
        border-bottom: none;
        margin-bottom: 0;
    }

    #accordionTemplate .accordion-toggle {
        height: 42px;
        line-height: 42px;
    }
</style>
<div id="wrapper">
    <div id="content">
        <ul class="breadcrumb">
            <li><a href="../../content/news/index.html?lang=en" class="glyphicons home"><i></i>AdminPlus</a></li>
            <li class="divider"></li>
            <li>Online Shop</li>
            <li class="divider"></li>
            <li>Products</li>
        </ul>
        <div class="separator bottom"></div>
        <div class="innerLR">
            <div class="widget widget-2">
                <div class="widget-head">
                    <h4 class="heading glyphicons picture"><i></i>Thiết lập giao diện</h4>
                    <div class="heading-buttons">
                        <div class="buttons pull-right">
                            <a href="#modal-simple" data-toggle="modal" class="btn btn-primary btn-icon glyphicons circle_question_mark"><i></i> Trợ giúp</a>
                            <a href="#" class="btn btn-primary btn-icon glyphicons edit" id="btnEditLayout"><i></i> Cập nhật</a>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="widget-body">
                    <div class="row-fluid">
                        <div class="span10 offset1">
                            <form method="post" class="accordion" id="accordionTemplate">
                                <input type="hidden" name="hidden" value="Save">
                                <div class="accordion-group">
                                    <div class="accordion-heading">
                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionTemplate" href="#collapseTrangChu">
                                        Trang chủ
                                        </a>
                                    </div>
                                    <div id="collapseTrangChu" class="accordion-body collapse in">
                                        <div class="accordion-inner">
                                            <div class="row">
                                                <div class="span7"><img class="imgPreview" src="/templates/<?=$GLOBALS['MAP'][$_SERVER['SERVER_NAME']]["template"]; ?>/images/layout/trang-chu.jpg"></div>
                                                <div class="span5">
                                                    <!-- Start inner -->
                                                    <div class="accordion" id="accordionTrangChuInner">
                                                        <!-- Start group -->
                                                        <div class="accordion-group">
                                                            <div class="accordion-heading">
                                                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionTrangChuInner" href="#collapseTrangChu1">1. Logo &amp; Biểu tượng</a>
                                                            </div>
                                                            <div id="collapseTrangChu1" class="accordion-body collapse in">
                                                                <div class="accordion-inner">
                                                                    <div class="control-group">
                                                                        <label>Logo</label>
                                                                        <p>Bạn nên chọn tập tin có kích thước ..., dung lượng ít hơn ...</p>
                                                                        <input type="file" name="trang-chu[Logo]">
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label>Biểu tượng</label>
                                                                        <p>Bạn nên chọn tập tin có kích thước ..., dung lượng ít hơn ...</p>
                                                                        <input type="file" name="trang-chu[favicon]">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End group -->

                                                        <!-- Start group -->
                                                        <div class="accordion-group">
                                                            <div class="accordion-heading">
                                                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionTrangChuInner" href="#collapseTrangChu2">2. Nội dung trên đầu trang</a>
                                                            </div>
                                                            <div id="collapseTrangChu2" class="accordion-body collapse">
                                                                <div class="accordion-inner">
                                                                    <div class="control-group">
                                                                        <label class="control-label">Số điện thoại</label>
                                                                        <div class="controls">
                                                                            <input type="text" value="<?= $proc->get_option('trang-chu[HeaderPhone]'); ?>" name="trang-chu[HeaderPhone]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label class="control-label">Địa chỉ</label>
                                                                        <div class="controls">
                                                                            <input type="text" value="<?= $proc->get_option('trang-chu[HeaderAddress]'); ?>" name="trang-chu[HeaderAddress]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label class="control-label">Email</label>
                                                                        <div class="controls">
                                                                            <input type="text" value="<?= $proc->get_option('trang-chu[HeaderEmail]'); ?>" name="trang-chu[HeaderEmail]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label class="control-label">Nội dung</label>
                                                                        <div class="controls">
                                                                            <input type="text" value="<?= $proc->get_option('trang-chu[HeaderContent]'); ?>" name="trang-chu[HeaderContent]">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End group -->

                                                        <!-- Start group -->
                                                        <div class="accordion-group">
                                                            <div class="accordion-heading">
                                                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionTrangChuInner" href="#collapseTrangChu3">3. Slider hình ảnh</a>
                                                            </div>
                                                            <div id="collapseTrangChu3" class="accordion-body collapse">
                                                                <div class="accordion-inner">
                                                                    <div class="control-group">
                                                                        <label class="control-label">Chọn hình 1</label>
                                                                        <div class="controls">
                                                                            <input type="file" name="trang-chu[Banner1_Image1]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label class="control-label">Liên kết hình 1</label>
                                                                        <p>Bỏ trống sẽ không chuyển trang</p>
                                                                        <div class="controls">
                                                                            <input type="text" value="<?= $proc->get_option('trang-chu[Banner1_Link1]'); ?>" name="trang-chu[Banner1_Link1]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label class="control-label">Chọn hình 2</label>
                                                                        <div class="controls">
                                                                            <input type="file" name="trang-chu[Banner2_Image2]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label class="control-label">Liên kết hình 2</label>
                                                                        <p>Bỏ trống sẽ không chuyển trang</p>
                                                                        <div class="controls">
                                                                            <input type="text" value="<?= $proc->get_option('trang-chu[Banner2_Link2]'); ?>" name="trang-chu[Banner2_Link2]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label class="control-label">Chọn hình 3</label>
                                                                        <div class="controls">
                                                                            <input type="file" name="trang-chu[Banner3_Image3]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label class="control-label">Liên kết hình 3</label>
                                                                        <p>Bỏ trống sẽ không chuyển trang</p>
                                                                        <div class="controls">
                                                                            <input type="text" value="<?= $proc->get_option('trang-chu[Banner3_Link3]'); ?>" name="trang-chu[Banner3_Link3]">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End group -->

                                                        <!-- Start group -->
                                                        <div class="accordion-group">
                                                            <div class="accordion-heading">
                                                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionTrangChuInner" href="#collapseTrangChu4">4. Danh sách sản phẩm</a>
                                                            </div>
                                                            <div id="collapseTrangChu4" class="accordion-body collapse">
                                                                <div class="accordion-inner">
                                                                    <div class="control-group">
                                                                        <label class="control-label">Số lượng sản phẩm</label>
                                                                        <div class="controls">
                                                                            <input type="number" value="<?= $proc->get_option('trang-chu[ProductList1_ProductNumber]'); ?>" name="trang-chu[ProductList1_ProductNumber]">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End group -->

                                                        <!-- Start group -->
                                                        <div class="accordion-group">
                                                            <div class="accordion-heading">
                                                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionTrangChuInner" href="#collapseTrangChu5">5. Banner trang chủ</a>
                                                            </div>
                                                            <div id="collapseTrangChu5" class="accordion-body collapse">
                                                                <div class="accordion-inner">
                                                                    <div class="control-group">
                                                                        <label class="control-label">Chọn hình</label>
                                                                        <div class="controls">
                                                                            <input type="file" name="trang-chu[Banner2][Image1]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label class="control-label">Liên kết đến</label>
                                                                        <p>Bỏ trống sẽ không chuyển trang</p>
                                                                        <div class="controls">
                                                                            <input type="text" value="<?= $proc->get_option('trang-chu[Banner2][Link1]'); ?>" name="trang-chu[Banner2][Link1]">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End group -->

                                                        <!-- Start group -->
                                                        <div class="accordion-group">
                                                            <div class="accordion-heading">
                                                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionTrangChuInner" href="#collapseTrangChu6">6. Danh sách sản phẩm</a>
                                                            </div>
                                                            <div id="collapseTrangChu6" class="accordion-body collapse">
                                                                <div class="accordion-inner">
                                                                    <div class="control-group">
                                                                        <label class="control-label">Số lượng sản phẩm</label>
                                                                        <div class="controls">
                                                                            <input type="number" value="<?= $proc->get_option('trang-chu[ProductList2][ProductNumber]'); ?>" name="trang-chu[ProductList2][ProductNumber]">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End group -->

                                                        <!-- Start group -->
                                                        <div class="accordion-group">
                                                            <div class="accordion-heading">
                                                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionTrangChuInner" href="#collapseTrangChu7">7. Banner trang chủ cuối trang</a>
                                                            </div>
                                                            <div id="collapseTrangChu7" class="accordion-body collapse">
                                                                <div class="accordion-inner">
                                                                    <div class="control-group">
                                                                        <label class="control-label">Chọn hình</label>
                                                                        <div class="controls">
                                                                            <input type="file" name="trang-chu[Banner3][Image1]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label class="control-label">Liên kết đến</label>
                                                                        <p>Bỏ trống sẽ không chuyển trang</p>
                                                                        <div class="controls">
                                                                            <input type="text" value="<?= $proc->get_option('trang-chu[Banner3][Link1]'); ?>" name="trang-chu[Banner3][Link1]">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End group -->

                                                        <!-- Start group -->
                                                        <div class="accordion-group">
                                                            <div class="accordion-heading">
                                                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionTrangChuInner" href="#collapseTrangChu8">8. Chân trang</a>
                                                            </div>
                                                            <div id="collapseTrangChu8" class="accordion-body collapse">
                                                                <div class="accordion-inner">
                                                                    <h4>Thông tin liên hệ</h4>
                                                                    <div class="control-group">
                                                                        <label>Tiêu đề</label>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" value="<?= $proc->get_option('trang-chu[ContactHeading]'); ?>" name="trang-chu[ContactHeading]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label>Mô tả</label>
                                                                        <div class="controls">
                                                                            <textarea class="form-control" name="trang-chu[ContactDescription]"><?= $proc->get_option('trang-chu[ContactDescription]'); ?></textarea>
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label>Địa chỉ</label>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" value="<?= $proc->get_option('trang-chu[ContactAddress]'); ?>" name="trang-chu[ContactAddress]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label>Email</label>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" value="<?= $proc->get_option('trang-chu[ContactEmail]'); ?>" name="trang-chu[ContactEmail]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label>Số điện thoại</label>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" value="<?= $proc->get_option('trang-chu[ContactPhone]'); ?>" name="trang-chu[ContactPhone]">
                                                                        </div>
                                                                    </div>
                                                                    <h4>Đăng ký nhận tin qua email</h4>
                                                                    <div class="control-group">
                                                                        <label>Tiêu đề</label>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" value="<?= $proc->get_option('trang-chu[EmailHeading]'); ?>" name="trang-chu[EmailHeading]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label>Mô tả thêm</label>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" value="<?= $proc->get_option('trang-chu[EmailDescription]'); ?>" name="trang-chu[EmailDescription]">
                                                                        </div>
                                                                    </div>
                                                                    <h4>Fanpage Facebook</h4>
                                                                    <div class="control-group">
                                                                        <label>Hiển thị</label>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" value="<?= $proc->get_option('trang-chu[Facebook]'); ?>" name="trang-chu[Facebook]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label>Đường link fanpage</label>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" value="<?= $proc->get_option('trang-chu[LinkFacebook]'); ?>" name="trang-chu[LinkFacebook]">
                                                                        </div>
                                                                    </div>
                                                                    <h4>Liên kết mạng xã hội</h4>
                                                                    <div class="control-group">
                                                                        <label>Facebook</label>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" value="<?= $proc->get_option('trang-chu[8][SocialFacebook]'); ?>" name="trang-chu[SocialFacebook]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label>Youtube</label>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" value="<?= $proc->get_option('trang-chu[SocialYoutube]'); ?>" name="trang-chu[SocialYoutube]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label>Google+</label>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" value="<?= $proc->get_option('trang-chu[SocialGoogle]'); ?>" name="trang-chu[SocialGoogle]">
                                                                        </div>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label>Instagram</label>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" value="<?= $proc->get_option('trang-chu[SocialInstagram]'); ?>" name="trang-chu[SocialInstagram]">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End group -->
                                                    </div>
                                                    <!-- End inner -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-group">
                                    <div class="accordion-heading">
                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionTemplate" href="#collapseNhomSanPham">
                                        Trang nhóm sản phẩm
                                        </a>
                                    </div>
                                    <div id="collapseNhomSanPham" class="accordion-body collapse">
                                        <div class="accordion-inner">
                                            <div class="row">
                                                <div class="span7"><img class="imgPreview" src="/templates/<?=$GLOBALS['MAP'][$_SERVER['SERVER_NAME']]["template"]; ?>/images/layout/nhom-san-pham.jpg"></div>
                                                <div class="span5">
                                                    <div class="accordion" id="accordionNhomSanPhamInner">
                                                        <!-- Start group -->
                                                        <div class="accordion-group">
                                                            <div class="accordion-heading">
                                                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionNhomSanPhamInner" href="#collapseNhomSanPham1">1. Sắp xếp sản phẩm</a>
                                                            </div>
                                                            <div id="collapseNhomSanPham1" class="accordion-body collapse in">
                                                                <div class="accordion-inner">
                                                                    <div class="control-group">
                                                                        <label>Hiển thị?</label>
                                                                        <span>Cho phép người dùng sắp xếp sản phẩm:</span>
                                                                        <input type="checkbox" name="san-pham:danh-muc[1][EnableSort]" <?= $proc->get_checked_option('san-pham:danh-muc[1][EnableSort]')?>>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End group -->
                                                        <!-- Start group -->
                                                        <div class="accordion-group">
                                                            <div class="accordion-heading">
                                                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionNhomSanPhamInner" href="#collapseNhomSanPham2">2. Danh sách sản phẩm</a>
                                                            </div>
                                                            <div id="collapseNhomSanPham2" class="accordion-body collapse">
                                                                <div class="accordion-inner">
                                                                    <div class="control-group">
                                                                        <label>Số lượng hiển thị?</label>
                                                                        <input type="number" name="san-pham:danh-muc[2][ProductNumber]" value="<?= $proc->get_option('san-pham:danh-muc[2][ProductNumber]')?>">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End group -->
                                                        <!-- Start group -->
                                                        <div class="accordion-group">
                                                            <div class="accordion-heading">
                                                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionNhomSanPhamInner" href="#collapseNhomSanPham3">3. Danh mục sản phẩm</a>
                                                            </div>
                                                            <div id="collapseNhomSanPham3" class="accordion-body collapse">
                                                                <div class="accordion-inner">
                                                                    <div class="control-group">
                                                                        <label>Hiển thị?</label>
                                                                        <span>Hiển thị danh mục sản phẩm cho người dùng:</span>
                                                                        <input type="checkbox" name="san-pham:danh-muc[3][EnableCategory]" <?= $proc->get_checked_option('san-pham:danh-muc[3][EnableCategory]')?>>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label>Tiêu đề</label>
                                                                        <input type="text" name="san-pham:danh-muc[3][CategoryHeading]" value="<?= $proc->get_option('san-pham:danh-muc[3][CategoryHeading]')?>">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End group -->
                                                        <!-- Start group -->
                                                        <div class="accordion-group">
                                                            <div class="accordion-heading">
                                                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionNhomSanPhamInner" href="#collapseNhomSanPham4">4. Banner hien thi</a>
                                                            </div>
                                                            <div id="collapseNhomSanPham4" class="accordion-body collapse">
                                                                <div class="accordion-inner">
                                                                    <div class="control-group">
                                                                        <label>Hiển thị?</label>
                                                                        <span>Hiển thị banner:</span>
                                                                        <input type="checkbox" name="san-pham:danh-muc[4][EnableBanner]" <?= $proc->get_checked_option('san-pham:danh-muc[4][EnableBanner]')?>>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label>Hinh 1</label>
                                                                        <input type="file" name="san-pham:danh-muc[4][Image1]">
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label>Link den</label>
                                                                        <input type="text" name="san-pham:danh-muc[4][Link1]" value="<?= $proc->get_option('san-pham:danh-muc[4][Link1]')?>">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End group -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-group">
                                    <div class="accordion-heading">
                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionTemplate" href="#collapseSanPham">
                                        Trang sản phẩm
                                        </a>
                                    </div>
                                    <div id="collapseSanPham" class="accordion-body collapse">
                                        <div class="accordion-inner">
                                            <div class="row">
                                                <div class="span7"><img class="imgPreview" src="/templates/<?=$GLOBALS['MAP'][$_SERVER['SERVER_NAME']]["template"]; ?>/images/layout/san-pham.jpg"></div>
                                                <div class="span5">
                                                    <div class="accordion" id="accordionSanPhamInner">
                                                        <!-- Start group -->
                                                        <div class="accordion-group">
                                                            <div class="accordion-heading">
                                                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionSanPhamInner" href="#collapseSanPham1">1. Tag sản phẩm</a>
                                                            </div>
                                                            <div id="collapseSanPham1" class="accordion-body collapse in">
                                                                <div class="accordion-inner">
                                                                    <div class="control-group">
                                                                        <label>Hiển thị?</label>
                                                                        <span>Hien thi tag san pahm:</span>
                                                                        <input type="checkbox" name="san-pham:chi-tiet[1][EnableTag]" <?= $proc->get_checked_option('san-pham:chi-tiet[1][EnableTag]')?>>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End group -->
                                                        <!-- Start group -->
                                                        <div class="accordion-group">
                                                            <div class="accordion-heading">
                                                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionSanPhamInner" href="#collapseSanPham2">2. Nut mang xa hoi</a>
                                                            </div>
                                                            <div id="collapseSanPham2" class="accordion-body collapse">
                                                                <div class="accordion-inner">
                                                                    <div class="control-group">
                                                                        <label>Hiển thị nut Like?</label>
                                                                        <span>Hien thi nut like san pahm:</span>
                                                                        <input type="checkbox" name="san-pham:chi-tiet[2][EnableLike]" <?= $proc->get_checked_option('san-pham:chi-tiet[2][EnableLike]')?>>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label>Hiển thị nut Share?</label>
                                                                        <span>Hien thi nut like san pahm:</span>
                                                                        <input type="checkbox" name="san-pham:chi-tiet[2][EnableShare]" <?= $proc->get_checked_option('san-pham:chi-tiet[2][EnableShare]')?>>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label>Hiển thị nut Send?</label>
                                                                        <span>Hien thi nut gui tin nhan:</span>
                                                                        <input type="checkbox" name="san-pham:chi-tiet[2][EnableSend]" <?= $proc->get_checked_option('san-pham:chi-tiet[2][EnableSend]')?>>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End group -->
                                                        <!-- Start group -->
                                                        <div class="accordion-group">
                                                            <div class="accordion-heading">
                                                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionSanPhamInner" href="#collapseSanPham3">3. Binh luan Facebook</a>
                                                            </div>
                                                            <div id="collapseSanPham3" class="accordion-body collapse">
                                                                <div class="accordion-inner">
                                                                    <div class="control-group">
                                                                        <label>Hiển thị?</label>
                                                                        <span>Hien thi nut like san pahm:</span>
                                                                        <input type="checkbox" name="san-pham:chi-tiet[2][EnableFacebookComment]" <?= $proc->get_checked_option('san-pham:chi-tiet[2][EnableFacebookComment]')?>>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End group -->
                                                        <!-- Start group -->
                                                        <div class="accordion-group">
                                                            <div class="accordion-heading">
                                                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionSanPhamInner" href="#collapseSanPham4">4. San pham lien quan</a>
                                                            </div>
                                                            <div id="collapseSanPham4" class="accordion-body collapse">
                                                                <div class="accordion-inner">
                                                                    <div class="control-group">
                                                                        <label>Hiển thị?</label>
                                                                        <span>Hien thi san pham lien quan:</span>
                                                                        <input type="checkbox" name="san-pham:chi-tiet[2][EnableRelatedProduct]" <?= $proc->get_checked_option('san-pham:chi-tiet[2][EnableRelatedProduct]')?>>
                                                                    </div>
                                                                    <div class="control-group">
                                                                        <label>So luong</label>
                                                                        <p>So luong san pham lien quan:</p>
                                                                        <input type="text" name="san-pham:chi-tiet[2][RelatedProductNumber]" value="<?= $proc->get_option('san-pham:chi-tiet[2][RelatedProductNumber]')?>">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- End group -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-group">
                                    <div class="accordion-heading">
                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionTemplate" href="#collapseBaiViet">
                                        Trang bài viết
                                        </a>
                                    </div>
                                    <div id="collapseBaiViet" class="accordion-body collapse">
                                        <div class="accordion-inner">
                                            <div class="row">
                                                <div class="span7"><img class="imgPreview" src="/templates/<?=$GLOBALS['MAP'][$_SERVER['SERVER_NAME']]["template"]; ?>/images/layout/bai-viet.jpg"></div>
                                                <div class="span5">Nội dung trang bài viết</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-group">
                                    <div class="accordion-heading">
                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionTemplate" href="#collapseLienHe">
                                        Trang liên hệ
                                        </a>
                                    </div>
                                    <div id="collapseLienHe" class="accordion-body collapse">
                                        <div class="accordion-inner">
                                            <div class="row">
                                                <div class="span7"><img class="imgPreview" src="/templates/<?=$GLOBALS['MAP'][$_SERVER['SERVER_NAME']]["template"]; ?>/images/layout/lien-he.jpg"></div>
                                                <div class="span5">Nội dung trang liên hệ</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
$( function(){
    $("#btnEditLayout").on("click", function(e){
        $("#accordionTemplate").submit();
        e.preventDefault();
    });
});
</script>