<?php defined( '_VALID_MOS' ) or die( include("../../content/news/404.php") );

	// include('../libraries/htmldom/simple_html_dom.php');
	include('../modules/modules.models.php');

    switch(@$_POST["hidden"]){

        case "";
        break;

        case "Save":
        		$myprocess = new PageData;

        		// Chỉ lấy giá trị trong pagelist, không lấy tất cả giá trị của _POST
        		$page_list = array("trang-chu", "san-pham:danh-muc", "san-pham:chi-tiet");
				foreach($page_list as $page){
					$page_data[$page] = $_POST[$page];
				}
				// Kết thúc    		
	        	$myprocess->save_page($page_data);
        	break;

        default:
        	$func->_redirect(".");
        break;
    }
